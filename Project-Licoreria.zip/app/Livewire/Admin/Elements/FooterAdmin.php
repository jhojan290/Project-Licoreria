<?php

namespace App\Livewire\Admin\Elements;

use Livewire\Component;

class FooterAdmin extends Component
{
    public function render()
    {
        return view('livewire.admin.elements.footer-admin');
    }
}
