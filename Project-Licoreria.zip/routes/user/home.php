<?php

use App\Livewire\User\Pages\HomePage;

Route::get('/inicio', HomePage::class)->name('user.home');