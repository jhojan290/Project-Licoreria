@extends('layouts.admin')

@section('content')

    <livewire:admin.products.modal-product-create />
    <livewire:admin.products.product-list />
    <livewire:admin.products.modal-product-delete />
@endsection

