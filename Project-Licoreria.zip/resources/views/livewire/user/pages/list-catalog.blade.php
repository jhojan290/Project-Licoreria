@extends('layouts.user')

@section('content')

    <livewire:user.pages.catalog-page />

@endsection